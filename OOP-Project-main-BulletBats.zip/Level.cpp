#include "Level.h"
#include <iostream>

Level::Level(int levelNumber) : levelNumber(levelNumber)
{
    if (levelNumber == 1)
    {
        enemies.push_back(Enemy("Skeleton", 50, 1));
        enemies.back().setAttackPower(5); // Set Skeleton's attack
        items.push_back(Item("Health Potion", "heal", 20));
    }
    else if (levelNumber == 2)
    {
        enemies.push_back(Enemy("Orc", 60, 2));
        enemies.back().setAttackPower(6); // Set Orc's attack
        items.push_back(Item("Sword", "weapon", 10));
    }
    else if (levelNumber == 3)
    {
        enemies.push_back(BossEnemy("Dragon", 100, 5));
        enemies.back().setAttackPower(15); // Set Dragon's attack
        items.push_back(Item("Dragon heart", "heal", 50));
    }
}

// Check if all enemies are defeated
bool Level::isCleared()
{
    for (Enemy& e : enemies)
    {
        if (e.is_alive())
        {
            return false;
        }
    }
    return true;
}

Level::~Level()
{
    enemies.clear(); // Clear the vector
    items.clear();   // Clear items (not dynamically allocated, so no need to delete)
}

// Get the next enemy to fight
Enemy *Level::getNextEnemy()
{
    for (Enemy& e : enemies)
    {
        if (e.is_alive())
        {
            return &e;
        }
    }
    return nullptr;
}

void Level::awardItems(Player *player)
{
    for (auto &item : items)
    {
        player->addItem(item);
    }
    items.clear();
}

void Level::displayLevelInfo() const
{
    std::cout << "Level " << levelNumber << " Summary:\n";
    std::cout << "Enemies remaining: ";
    for (Enemy e : enemies)
    {
        if (e.is_alive())
            std::cout << e.getName() << " ";
    }
    std::cout << "\nItems available: ";
    for (const auto &item : items)
    {
        std::cout << item.get_name() << " ";
    }
    std::cout << "\n";
}

int Level::getEnemyCount() const
{

    return enemies.size();
}

int Level::getItemCount() const
{
    return items.size();
}
