#include "Game.h"

int main() {
    Game game;
    game.startGame();
    return 0;
}